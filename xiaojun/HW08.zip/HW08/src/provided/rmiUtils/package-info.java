/**
 * 
 */
/**
 * Utilities for managing RMI plus the declarations of shared RMI-related constants.  
 * Students should use the utilities defined here to perform RMI-related 
 * management operations.  All system MUST utilize the constants defined here.
 * This package also contains the "server.policy" file needed to initialize RMI's 
 * security manager.     
 * @author Stephen Wong
 *
 */
package provided.rmiUtils;