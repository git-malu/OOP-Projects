package model;

/**
 * Main to mini adapter
 * @author Gengwu Li, Zhaohan Jia
 * @version 1.0, Nov 14, 2016
 */
public interface IMain2MiniAdpt {

}
