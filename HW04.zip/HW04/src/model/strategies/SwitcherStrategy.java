package model.strategies;

import model.balls.Ball;

/**
 * A decorator that encapsulate another strategy, which enables the strategy to be changed
 * at run time.
 * @author Yuchang Shen and Yibing Zhang
 *
 */
public class SwitcherStrategy implements IUpdateStrategy {

	private IUpdateStrategy _strategy = new StraightStrategy();

	/**
	 * Setter for the strategy.
	 * @param newStrategy
	 * 			The new strategy for the switcher balls to be changed.
	 */
	public void setStrategy(IUpdateStrategy newStrategy) {
		_strategy = newStrategy;
	}

	@Override
	public void updateState(Ball ball) {
		// TODO Auto-generated method stub
		_strategy.updateState(ball);
	}

}
